def mean(data):
    addtion=0
    length_data=0
    for i in (data):
        addtion+=i
        length_data+=1
    return addtion/length_data
    